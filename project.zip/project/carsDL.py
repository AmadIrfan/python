class carsDL:

    carsList = []

    def addCarsIntoList(temp):
        carsDL.carsList.append(temp)
