from Muser import Muser


class MuserDL:
    muserList = []

    @staticmethod
    def addMuserIntoList(user):
        MuserDL.muserList.append(user)
