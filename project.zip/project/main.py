from msvcrt import getch
from UI import UI
from MuserDL import MuserDL
from Muser import Muser
from customerDL import customerDL
from adminUI import AdminUI
from userUI import UserUI
from carsDL import carsDL
from carsUI import CarsUI
from cars import cars
from os import system


def main():
    getch()
    inputVar = "0"
    while (
        inputVar == "4"
        or inputVar == "3"
        or inputVar == "2"
        or inputVar == "1"
        or inputVar == "0"
    ):
        UI.clearScreen()
        inputVar = UI.MainMenu()
        if inputVar == "1":
            UI.clearScreen()
            UserInput = 0
            while UserInput <= 4:
                UserInput = UserUI.userMenu()
                if UserInput == 1:
                    user = 0
                    while user <= 4:
                        UI.clearScreen()
                        user = UserUI.existing_user_manu()
                        if user==1:
                            CarsUI.ShowCars()
                        if user==2:
                            CarsUI.BookCars()
                        # if user==3:
                        if user == 4:
                            break
                if UserInput == 2:
                    UI.clearScreen()
                    temp = UserUI.newcustomer()
                    MuserDL.addMuserIntoList(temp)
                if UserInput == 3:
                    break
        if inputVar == "2":
            UI.clearScreen()
            adminInput = 0
            while adminInput <= 8:
                adminInput = AdminUI.adminMenu()
                if adminInput == 1:
                    UI.clearScreen()
                    Admin = AdminUI.addAdmin()
                    MuserDL.addMuserIntoList(Admin)
                if adminInput == 2:
                    UI.clearScreen()
                    car = CarsUI.addCars()
                    carsDL.addCarsIntoList(car)
                # if adminInput == 3:
                # if adminInput == 4:
                # if adminInput == 5:
                if adminInput == 6:
                    UI.clearScreen()
                    CarsUI.ShowCars()
                # if adminInput == 7:
                if adminInput == 8:
                    break
        if inputVar == "3":
            UI.clearScreen()
            UI.tearmsCondition()
        if inputVar == "4":
            UI.clearScreen()
            break


if __name__ == "__main__":
    main()
